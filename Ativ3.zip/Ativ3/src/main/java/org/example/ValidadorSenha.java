package org.example;

public class ValidadorSenha
{
    public static boolean tamanhoValido(String senha) {
        return senha.length() >= 8;
    }

    public static boolean temCaractereEspecial(String senha) {

        for (int i = 0; i < senha.length(); i++) {
            char c = senha.charAt(i);

            if (c == '@' || c == '#' || c == '$' ||
                    c == '%' || c == '&' || c == '*') {
                return true;
            }
        }

        return false;
    }
}
