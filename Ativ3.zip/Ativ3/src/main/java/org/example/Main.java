package org.example;
import java.util.Scanner;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a senha: ");
        String senha = scanner.nextLine();

        boolean tamanho = ValidadorSenha.tamanhoValido(senha);
        boolean especial = ValidadorSenha.temCaractereEspecial(senha);

        if (tamanho && especial) {
            System.out.println("Senha Válida");
        } else {
            System.out.println("Senha Inválida");

            if (!tamanho) {
                System.out.println("- Deve possuir pelo menos 8 caracteres.");
            }

            if (!especial) {
                System.out.println("- Deve conter caractere especial.");
            }
        }

        scanner.close();
    }
}