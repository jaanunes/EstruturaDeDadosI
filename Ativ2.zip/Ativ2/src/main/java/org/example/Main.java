package org.example;

import java.util.Scanner;

public class Main
{
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor (múltiplo de 10): ");
        int valor = scanner.nextInt();

        int notas50 = CaixaEletronico.calcularNotas50(valor);
        int notas20 = CaixaEletronico.calcularNotas20(valor);
        int notas10 = CaixaEletronico.calcularNotas10(valor);

        System.out.println("Notas de R$50: " + notas50);
        System.out.println("Notas de R$20: " + notas20);
        System.out.println("Notas de R$10: " + notas10);

        scanner.close();
    }
}