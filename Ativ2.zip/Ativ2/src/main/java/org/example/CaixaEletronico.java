package org.example;

public class CaixaEletronico
{

    public static int calcularNotas50(int valor)
    {
        return valor / 50;
    }

    public static int calcularNotas20(int valor)
    {
        int resto = valor % 50;
        return resto / 20;
    }

    public static int calcularNotas10(int valor)
    {
        int resto50 = valor % 50;
        int resto20 = resto50 % 20;
        return resto20 / 10;
    }
}
