package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main
{
    public static void main(String[] args) {

        double[] notas = {7.5, 4.0, 9.2, 5.5, 8.0, 6.5, 3.2, 10.0, 7.0, 5.8};

        double media = ProcessadorNotas.calcularMedia(notas);

        int acimaDaMedia = ProcessadorNotas.contarAcimaDaMedia(notas, media);

        double maior = ProcessadorNotas.encontrarMaior(notas);

        System.out.println("Média das notas: " + media);
        System.out.println("Quantidade acima da média: " + acimaDaMedia);
        System.out.println("Maior nota: " + maior);
    }
}