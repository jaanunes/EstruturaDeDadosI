package org.example;

public class ProcessadorNotas
{
    public static double calcularMedia(double[] notas)
    {
        double soma = 0;

        for (int i = 0; i < notas.length; i++)
        {
            soma += notas[i];
        }

        return soma / notas.length;
    }

    public static int contarAcimaDaMedia(double[] notas, double media)
    {
        int contador = 0;

        for (int i = 0; i < notas.length; i++)
        {
            if (notas[i] > media) {
                contador++;
            }
        }

        return contador;
    }

    public static double encontrarMaior(double[] notas)
    {
        double maior = notas[0];

        for (int i = 1; i < notas.length; i++)
        {
            if (notas[i] > maior) {
                maior = notas[i];
            }
        }
        return maior;
    }
}
