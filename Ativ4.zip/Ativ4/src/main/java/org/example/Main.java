package org.example;
import java.util.Scanner;

public class Main
{

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o tempo em segundos: ");
        int total = scanner.nextInt();

        int horas = ConversorTempo.calcularHoras(total);
        int minutos = ConversorTempo.calcularMinutos(total);
        int segundos = ConversorTempo.calcularSegundos(total);

        System.out.println(horas + "h, " + minutos + "min e " + segundos + "seg");

        scanner.close();
    }
}