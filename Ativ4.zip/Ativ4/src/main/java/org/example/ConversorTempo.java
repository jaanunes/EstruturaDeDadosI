package org.example;

public class ConversorTempo {

    public static int calcularHoras(int totalSegundos) {
        return totalSegundos / 3600;
    }

    public static int calcularMinutos(int totalSegundos) {
        int resto = totalSegundos % 3600;
        return resto / 60;
    }

    public static int calcularSegundos(int totalSegundos) {
        return totalSegundos % 60;
    }
}

