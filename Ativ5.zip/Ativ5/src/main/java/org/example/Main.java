package org.example;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Quantidade de números: ");
        int tamanho = scanner.nextInt();

        int[] numeros = new int[tamanho];

        for (int i = 0; i < tamanho; i++) {
            System.out.print("Digite o número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        if (VerificadorNumeros.saoUnicos(numeros)) {
            System.out.println("Todos os números são distintos.");
        } else {
            System.out.println("Há números repetidos.");
        }

        scanner.close();
    }
}